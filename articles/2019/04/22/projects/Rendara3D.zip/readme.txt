Demo 1:
	WASD: move camera
	arrows: move light

Demo 2:
	WASD: move camera
	arrow up/down: cycle day/night

Demo 3:
	arrow left/right: move the ball
	arrow up/down: unstick the ball
